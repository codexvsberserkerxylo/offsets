#ifdef _MSC_VER
#pragma runtime_checks("s", off)
#endif
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#ifndef _SCL_SECURE_NO_WARNINGS
#define _SCL_SECURE_NO_WARNINGS
#endif
#ifndef _CRT_NONSTDC_NO_WARNINGS
#define _CRT_NONSTDC_NO_WARNINGS
#endif
// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details
#pragma once

#include "lobject.h"

#define sizevector() (sizeof(LuauVector))

LUAI_FUNC LuauVector* luaVec_newvector(lua_State* L, double x, double y, double z, double w);
LUAI_FUNC void luaVec_freevector(lua_State* L, LuauVector* v, struct lua_Page* page);
