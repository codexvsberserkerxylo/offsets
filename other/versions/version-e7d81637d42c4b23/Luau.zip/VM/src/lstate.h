#ifdef _MSC_VER
#pragma runtime_checks("s", off)
#endif
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#ifndef _SCL_SECURE_NO_WARNINGS
#define _SCL_SECURE_NO_WARNINGS
#endif
#ifndef _CRT_NONSTDC_NO_WARNINGS
#define _CRT_NONSTDC_NO_WARNINGS
#endif
// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details
// This code is based on Lua 5.x implementation licensed under MIT License; see lua_LICENSE.txt for details
#pragma once

#include "lobject.h"
#include <Roblox/Offsets.hpp>
#include <Roblox/Encryptions.hpp>
#include "ltm.h"
#include "ludata.h"

// registry
#define registry(L) (&L->global->registry)

// extra stack space to handle TM calls and some other extras
#define EXTRA_STACK 5

#define BASIC_CI_SIZE 8

#define BASIC_STACK_SIZE (2 * LUA_MINSTACK)

// clang-format off
typedef struct stringtable
{
    int size; /* offset 0 */
    int nuse; /* offset 4 */
    TString** hash; /* offset 8 */
} stringtable;
// clang-format on

/*
** information about a call
**
** the general Lua stack frame structure is as follows:
** - each function gets a stack frame, with function "registers" being stack slots on the frame
** - function arguments are associated with registers 0+
** - function locals and temporaries follow after; usually locals are a consecutive block per scope, and temporaries are allocated after this, but
*this is up to the compiler
**
** when function doesn't have varargs, the stack layout is as follows:
** ^ (func) ^^ [fixed args] [locals + temporaries]
** where ^ is the 'func' pointer in CallInfo struct, and ^^ is the 'base' pointer (which is what registers are relative to)
**
** when function *does* have varargs, the stack layout is more complex - the runtime has to copy the fixed arguments so that the 0+ addressing still
*works as follows:
** ^ (func) [fixed args] [varargs] ^^ [fixed args] [locals + temporaries]
**
** computing the sizes of these individual blocks works as follows:
** - the number of fixed args is always matching the `numparams` in a function's Proto object; runtime adds `nil` during the call execution as
*necessary
** - the number of variadic args can be computed by evaluating (ci->base - ci->func - 1 - numparams)
**
** the CallInfo structures are allocated as an array, with each subsequent call being *appended* to this array (so if f calls g, CallInfo for g
*immediately follows CallInfo for f)
** the `nresults` field in CallInfo is set by the caller to tell the function how many arguments the caller is expecting on the stack after the
*function returns
** the `flags` field in CallInfo contains internal execution flags that are important for pcall/etc, see LUA_CALLINFO_*
*/
// clang-format off
typedef struct CallInfo
{
    TValue* base; /* offset 0 */
    TValue* top; /* offset 8 */
    TValue* func; /* offset 16 */
    Proto* p; /* offset 24 */
    union /* offset 32 */
    {
        const Instruction* savedpc; /* offset 0 */
        int errfunc; /* offset 0 */
    };
    int nresults; /* offset 40 */
    unsigned int flags; /* offset 44 */
} CallInfo;
// clang-format on

#define LUA_CALLINFO_RETURN (1 << 0) // should the interpreter return after returning from this callinfo? first frame must have this set
#define LUA_CALLINFO_HANDLE (1 << 1) // should the error thrown during execution get handled by continuation from this callinfo? func must be C
#define LUA_CALLINFO_NATIVE (1 << 2) // should this function be executed using execution callback for native code
#define LUA_CALLINFO_OPYIELD (1 << 3) // call frame has yielded on a non-call opcode and requires luau_finishop
#define LUA_CALLINFO_PCALL (1 << 4) // call frame was setup by a synthetic protected call and requires luau_pospcallsuccess

#define curr_func(L) (clvalue(L->ci->func))
#define ci_func(ci) (clvalue((ci)->func))
#define f_isLua(ci) (!ci_func(ci)->isC)
#define isLua(ci) (ttisfunction((ci)->func) && f_isLua(ci))

struct GCStats
{
    // data for proportional-integral controller of heap trigger value
    int32_t triggerterms[32] = {0};
    uint32_t triggertermpos = 0;
    int32_t triggerintegral = 0;

    size_t atomicstarttotalsizebytes = 0;
    size_t endtotalsizebytes = 0;
    size_t heapgoalsizebytes = 0;

    double starttimestamp = 0;
    double atomicstarttimestamp = 0;
    double endtimestamp = 0;
};

#ifdef LUAI_GCMETRICS
struct GCCycleMetrics
{
    size_t starttotalsizebytes = 0;
    size_t heaptriggersizebytes = 0;

    double pausetime = 0.0; // time from end of the last cycle to the start of a new one

    double starttimestamp = 0.0;
    double endtimestamp = 0.0;

    double marktime = 0.0;
    double markassisttime = 0.0;
    double markmaxexplicittime = 0.0;
    size_t markexplicitsteps = 0;
    size_t markwork = 0;

    double atomicstarttimestamp = 0.0;
    size_t atomicstarttotalsizebytes = 0;
    double atomictime = 0.0;

    // specific atomic stage parts
    double atomictimeupval = 0.0;
    double atomictimeweak = 0.0;
    double atomictimegray = 0.0;
    double atomictimeembedder = 0.0;
    double atomictimeclear = 0.0;

    double sweeptime = 0.0;
    double sweepassisttime = 0.0;
    double sweepmaxexplicittime = 0.0;
    size_t sweepexplicitsteps = 0;
    size_t sweepwork = 0;

    size_t assistwork = 0;
    size_t explicitwork = 0;

    size_t propagatework = 0;
    size_t propagateagainwork = 0;

    size_t endtotalsizebytes = 0;
};

struct GCMetrics
{
    double stepexplicittimeacc = 0.0;
    double stepassisttimeacc = 0.0;

    // when cycle is completed, last cycle values are updated
    uint64_t completedcycles = 0;

    GCCycleMetrics lastcycle;
    GCCycleMetrics currcycle;
};
#endif

// Callbacks that can be used to to redirect code execution from Luau bytecode VM to a custom implementation (AoT/JiT/sandboxing/...)
struct lua_ExecutionCallbacks
{
    void* context;
    void (*close)(lua_State* L);                 // called when global VM state is closed
    void (*destroy)(lua_State* L, Proto* proto); // called when function is destroyed
    int (*enter)(lua_State* L, Proto* proto);    // called when function is about to start/resume (when execdata is present), return 0 to exit VM
    void (*disable)(lua_State* L, Proto* proto); // called when function has to be switched from native to bytecode in the debugger
    size_t (*getmemorysize)(lua_State* L, Proto* proto); // called to request the size of memory associated with native part of the Proto
    uint8_t (*gettypemapping)(lua_State* L, const char* str, size_t len); // called to get the userdata type index
    char* (*getcounterdata)(
        lua_State* L,
        Proto* proto,
        size_t* count
    ); // called to get the execution counter data and count {uint32_t, uint32_t, uint64_t}
    Proto* (*inlinefunction)(lua_State* L, Closure* caller, Closure* target, uint32_t pc); // called when inlining threshold is reached
};

struct lua_UdataDirectAccessData
{
    TValue indextm;
    TValue newindextm;
    TValue namecalltm;
    lua_UserdataDirectAccess index;
    lua_UserdataDirectAccess newindex;
    lua_UserdataDirectNamecall namecall;
};

/*
** `global state', shared by all threads of this state
*/
// clang-format off
typedef struct global_State
{
    size_t GCthreshold; /* offset 0 */
    size_t totalbytes; /* offset 8 */
    lua_Alloc frealloc; /* offset 16 */
    void* ud; /* offset 24 */
    stringtable strt; /* offset 32 */
    unsigned char currentwhite; /* offset 48 */
    unsigned char gcstate; /* offset 49 */
    unsigned char gap_00[0x2]; /* offset 50 */
    int gcgoal; /* offset 52 */
    int gcstepmul; /* offset 56 */
    int gcstepsize; /* offset 60 */
    GCObject* gray; /* offset 64 */
    GCObject* grayagain; /* offset 72 */
    GCObject* weak; /* offset 80 */
    lua_Page* freepages[40]; /* offset 88 */
    lua_Page* freegcopages[40]; /* offset 408 */
    lua_Page* sweepgcopage; /* offset 728 */
    lua_Page* allpages; /* offset 736 */
    UpVal uvhead; /* offset 744 */
    lua_Page* allgcopages; /* offset 784 */
    lua_State* mainthread; /* offset 792 */
    TString* tmname[21]; /* offset 800 */
    TString* ttname[14]; /* offset 968 */
    LuaTable* mt[14]; /* offset 1080 */
    TValue pseudotemp; /* offset 1192 */
    TValue registry; /* offset 1208 */
    uintptr_t registryfree; /* offset 1224 */
    struct lua_jmpbuf* errorjmp; /* offset 1232 */
    unsigned __int64 ptrenckey[4]; /* offset 1240 */
    lua_Callbacks cb; /* offset 1272 */
    unsigned __int64 rngstate; /* offset 1376 */
    lua_ExecutionCallbacks ecb; /* offset 1384 */
    unsigned char ecbdata[512]; /* offset 1456 */
    lua_UdataDirectAccessData udatadirect[130]; /* offset 1968 */
    size_t memcatbytes[256]; /* offset 11328 */
    void (*udatagc[128])(struct lua_State*, void*); /* offset 13376 */
    lua_UserdataMark udatamark[128]; /* offset 14400 */
    LuaTable* udatamt[128]; /* offset 15424 */
    TValue weakregistry; /* offset 16448 */
    int weakregistryfree; /* offset 16464 */
    unsigned char gap_02[0x4]; /* offset 16468 */
    lua_EmbedderGc embeddergc; /* offset 16472 */
    TString* lightuserdataname[128]; /* offset 16480 */
    struct LuaTable* udatadirectfields[130]; /* offset 17504 */
    Closure* builtinPcall; /* offset 18544 */
    Closure* builtinXpcall; /* offset 18552 */
    unsigned __int64 ptrenckeynew[8]; /* offset 18560 */
    unsigned char ptrencactive; /* offset 18624 */
    struct GCStats gcstats; /* offset 18632 */
    unsigned int lastprotoid; /* offset 18816 */
#ifdef LUAI_GCMETRICS
    GCMetrics gcmetrics; /* offset 18824 */
#endif
} global_State;
// clang-format on

/*
** `per thread' state
*/
// clang-format off
struct lua_State
{
    CommonHeader; /* offset 0 */
    unsigned char status; /* offset 3 */
    unsigned char activememcat; /* offset 4 */
    bool singlestep; /* offset 5 */
    unsigned char isactive; /* offset 6 */
    unsigned short nCcalls; /* offset 8 */
    unsigned short baseCcalls; /* offset 10 */
    unsigned int cachedslot; /* offset 12 */
    LSTATE_STACKSIZE_ENC<int> stacksize; /* offset 16 */
    int size_ci; /* offset 20 */
    CallInfo* end_ci; /* offset 24 */
    CallInfo* base_ci; /* offset 32 */
    GCObject* gclist; /* offset 40 */
    TString* namecall; /* offset 48 */
    LuaTable* gt; /* offset 56 */
    UpVal* openupval; /* offset 64 */
    struct RobloxExtraSpace* userdata; /* offset 72 */
    CallInfo* ci; /* offset 80 */
    TValue* base; /* offset 88 */
    TValue* stack; /* offset 96 */
    TValue* stack_last; /* offset 104 */
    global_State* global; /* offset 112 */
    TValue* top; /* offset 120 */
};
// clang-format on

/*
** Union of all collectible objects
*/
union GCObject
{
    GCheader gch;
    struct TString ts;
    struct Udata u;
    struct Closure cl;
    struct LuaTable h;
    struct Proto p;
    struct UpVal uv;
    struct lua_State th; // thread
    struct LuauBuffer buf;
    struct LuauClass lclass;
    struct LuauObject lobject;
    struct LuauVector vec;
};

// macros to convert a GCObject into a specific value
#define gco2ts(o) check_exp((o)->gch.tt == LUA_TSTRING, &((o)->ts))
#define gco2u(o) check_exp((o)->gch.tt == LUA_TUSERDATA, &((o)->u))
#define gco2cl(o) check_exp((o)->gch.tt == LUA_TFUNCTION, &((o)->cl))
#define gco2h(o) check_exp((o)->gch.tt == LUA_TTABLE, &((o)->h))
#define gco2p(o) check_exp((o)->gch.tt == LUA_TPROTO, &((o)->p))
#define gco2uv(o) check_exp((o)->gch.tt == LUA_TUPVAL, &((o)->uv))
#define gco2th(o) check_exp((o)->gch.tt == LUA_TTHREAD, &((o)->th))
#define gco2buf(o) check_exp((o)->gch.tt == LUA_TBUFFER, &((o)->buf))
#define gco2class(o) check_exp((o)->gch.tt == LUA_TCLASS, &((o)->lclass))
#define gco2object(o) check_exp((o)->gch.tt == LUA_TOBJECT, &((o)->lobject))
#define gco2vec(o) check_exp((o)->gch.tt == LUA_TVECTOR, &((o)->vec))

// macro to convert any Lua object into a GCObject
#define obj2gco(v) check_exp(iscollectable(v), cast_to(GCObject*, (v) + 0))

LUAI_FUNC lua_State* luaE_newthread(lua_State* L);
LUAI_FUNC void luaE_freethread(lua_State* L, lua_State* L1, struct lua_Page* page);
